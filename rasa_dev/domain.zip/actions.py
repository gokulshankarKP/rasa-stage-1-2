from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet, SessionStarted, ActionExecuted, EventType

import pandas as pd
import requests
import os
from  dotenv import load_dotenv, find_dotenv
find_dotenv()
load_dotenv()
import mysql.connector
import boto3
import numpy as np
from sentence_transformers import SentenceTransformer, util
import json
import ast
from tqdm import tqdm
import time
import string
from nltk.corpus import stopwords
import nltk
import torch

nltk.download('stopwords')
stop_words = set(stopwords.words('english'))
s3_client = boto3.client("s3")
embedder = SentenceTransformer('paraphrase-MiniLM-L6-v2')


# Read CSV from S3
def read_csv_from_s3(key: str, bucket="aca-qdap-production-transfer"):
    s3_df_obj = s3_client.get_object(Bucket=bucket, Key=key)
    dataframe = pd.read_csv(s3_df_obj['Body'])
    return dataframe

# Set Serial Numbers DataType
def dtype_sn(df, col_name: str):
    df[col_name] = df[col_name].astype(str)
    df[col_name] = df[col_name].str.split(".").str[0]
    return df[col_name]

# Set RMA Numbers DataType
def dtype_rma(df, col_name: str):
    df[col_name] = pd.to_numeric(df[col_name])
    df[col_name] = df[col_name].astype("Int64")
    return df[col_name]

# Define the preprocessing function
def preprocess_text(text):
    text = text.lower()  # Convert to lowercase
    text = text.translate(str.maketrans('', '', string.punctuation))  # Remove punctuation
    text = ' '.join(text.split())  # Remove extra whitespace
    text = ' '.join([word for word in text.split() if word not in stop_words])  # Remove stopwords
    return text


trial_dict = {'211054628': {'shipped_date':'27-10-2022', 'warranty_up_date':'27-10-2024', 'model_name':'1200X', 'warranty_status':'InWarranty', 'prob_Non_Repairable':30, 'prob_Repaired':62.5, 'prob_NFF':7.5, 'FUD':'Repaired', 'FUD_probability':62.5, 'test_doc_req_or_not':False, 'ETD':24, 'estimated_cost':1250},
              '203753497': {'shipped_date':'27-10-2021', 'warranty_up_date':'27-10-2023', 'model_name':'100M', 'warranty_status':'OutWarranty', 'prob_Non_Repairable':'Unknown', 'prob_Repaired':'Unknown', 'prob_NFF':'Unknown', 'FUD':'Unknown', 'FUD_probability':'Unknown', 'test_doc_req_or_not':False, 'ETD':45, 'estimated_cost':750},
              '212154619': {'shipped_date':'27-10-2022', 'warranty_up_date':'27-10-2024', 'model_name':'400ZR', 'warranty_status':'InWarranty', 'prob_Non_Repairable':30, 'prob_Repaired':8.5, 'prob_NFF':61.5, 'FUD':'NFF', 'FUD_probability':61.5, 'test_doc_req_or_not':True, 'ETD':30, 'estimated_cost':890},
              '231250014': {'shipped_date':'27-10-2022', 'warranty_up_date':'27-10-2024', 'model_name':'DCFP2', 'warranty_status':'InWarranty', 'prob_Non_Repairable':30, 'prob_Repaired':27.2, 'prob_NFF':42.8, 'FUD':'Unknown', 'FUD_probability':'Unknown', 'test_doc_req_or_not':False, 'ETD':30, 'estimated_cost':1850},
              '152304563': {'shipped_date':'27-10-2021', 'warranty_up_date':'27-10-2023', 'model_name':'100M', 'warranty_status':'OutWarranty', 'prob_Non_Repairable':50.6, 'prob_Repaired':40, 'prob_NFF':9.4, 'FUD':'Unknown', 'FUD_probability':'Unknown', 'test_doc_req_or_not':False, 'ETD':30, 'estimated_cost':2500},
              }
#############################################################################################################################################################################################################
#############################################################################################################################################################################################################
#############################################################################################################################################################################################################
#############################################################################################################################################################################################################









# class ActionCheckSerialNumber(Action):
#     def name(self) -> Text:
#         return "action_check_serial_number"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         sn_pn_mapping = pd.read_csv("SN_PN_mapping.csv")
#         sn_pn_mapping['serial_number'] = sn_pn_mapping['serial_number'].astype(str)
#         sn_pn_mapping['part_number'] = sn_pn_mapping['part_number'].astype(str)
#         sn_list = sn_pn_mapping['serial_number'].to_list()
#         serial_number = str(tracker.get_slot("serial_number"))

#         sn_is_valid = serial_number in sn_list
#         part_number = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['part_number'].iloc[0]
#         model_name = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['model'].iloc[0]

#         if any(char.isalpha() for char in part_number.split('-')[-1]):
#             check_if_engineering_sample = True
#         else:
#             check_if_engineering_sample = False

#         # initial_address_validation = False

#         shipped_date = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['shipped_date'].iloc[0]
#         warranty_up_date = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['warranty_up_date'].iloc[0]

#         tod = pd.Timestamp.today()
#         Warranty_Up_Date = pd.Timestamp(warranty_up_date)
#         Shipped_Date = pd.Timestamp(shipped_date)


#         if tod > Warranty_Up_Date:
#             warrantable = False
#         else:
#             warrantable = True

#         if warrantable:
#             warranty_status = "InWarranty"
#         else:
#             warranty_status = "OutWarranty"


#         difference_in_days = (tod - Shipped_Date).days

#         if difference_in_days > 60:
#             DOA_should_be_part_of_POF = False
#         else:
#             DOA_should_be_part_of_POF = True


#         db_name = "newacaciaAppPortal"
#         mydb = mysql.connector.connect(
#             host=os.environ["rds_host"],
#             user=os.environ["name"],
#             password=os.environ["password"],
#             database=db_name
#         )

#         QUERY = "select part, is_active FROM newacaciaAppPortal.account_customerpartmodel where part = %s;"
#         part_number_status = pd.read_sql_query(QUERY, con=mydb, params=[part_number])


#         if part_number_status['is_active'][0] == 1:
#             serviceable = True
#         else:
#             serviceable = False
            

#         if sn_is_valid:
#             return [SlotSet("DOA_should_be_part_of_POF", DOA_should_be_part_of_POF), SlotSet("serviceable", serviceable), SlotSet("shipped_date", shipped_date), SlotSet("model_name", model_name), SlotSet("warranty_status", warranty_status), SlotSet("warrantable", warrantable), SlotSet("sn_is_valid", sn_is_valid), SlotSet("part_number", part_number), SlotSet("check_if_engineering_sample", check_if_engineering_sample)]
#         else:
#             return [SlotSet("sn_is_valid", sn_is_valid)]
  


# # class ActionGetPredictedCategories(Action):
# #     def name(self) -> Text:
# #         return "action_get_predicted_categories"

# #     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

# #         # problem_description = tracker.get_slot("problem_description")

# #         # response = requests.post('http://localhost:8000/classify', json={"sentence": problem_description})
# #         # json_response = response.json()

# #         # predicted_category_1 = json_response['predictions'][0]['label']
# #         # predicted_category_2 = json_response['predictions'][1]['label']
# #         # predicted_category_3 = json_response['predictions'][2]['label']

# #         predicted_category_1 = "Signal Integrity Issues"
# #         predicted_category_2 = "Connector Damaged"
# #         predicted_category_3 = "Electrical Connector Damaged"


# #         return [SlotSet("predicted_category_1", predicted_category_1), SlotSet("predicted_category_2", predicted_category_2), SlotSet("predicted_category_3", predicted_category_3)]


# class ActionGetFUDDetails(Action):
#     def name(self) -> Text:
#         return "action_get_FUD_details"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:


#         serial_number = tracker.get_slot("serial_number")
#         model_from_backend = tracker.get_slot("model_name")
#         problem_description = tracker.get_slot("problem_description")

#         FUD_df = pd.read_csv("FUD.csv")
#         FUD_df['embeddings'] = FUD_df['embeddings'].apply(lambda x: torch.tensor(eval(x)))
#         filtered_df = FUD_df[FUD_df['model'] == model_from_backend].reset_index(drop = True)


#         if filtered_df.shape[0]>0:
#         # Corpus with example sentences
#             corpus_embeddings = filtered_df['embeddings'].tolist()
#             query_embedding = embedder.encode(problem_description, convert_to_tensor=True)

#             hits = util.semantic_search(query_embedding, corpus_embeddings, top_k=1)
#             hit = hits[0][0]

#             if hit['score']>0.7:
#                 prob_Non_Repairable = int(filtered_df['prob_Non-Repairable'][hit['corpus_id']])
#                 prob_Repaired = int(filtered_df['prob_Repaired'][hit['corpus_id']])
#                 prob_NFF = int(filtered_df['prob_NFF'][hit['corpus_id']])
#                 probabilities = {'Non_Repairable': prob_Non_Repairable, 'Repaired': prob_Repaired, 'NFF': prob_NFF}
#             else:
#                 prob_Non_Repairable = prob_Repaired = prob_NFF = 'Unknown'
#         else:
#             prob_Non_Repairable = prob_Repaired = prob_NFF = 'Unknown'

#         FUD = 'Unknown'
#         FUD_probability = 'Unknown'   

#         if isinstance(prob_Non_Repairable, int):
#             # Check if any of the probabilities exceed the threshold
#             for key, value in probabilities.items():
#                 if value > 60:
#                     FUD = key
#                     FUD_probability = value
#                     break  # Stop after finding the first probability that exceeds the threshold

#         if FUD != 'Unknown':
#             valid_FUD_exists = True
#         else:
#             valid_FUD_exists = False


#         if FUD=="NFF":
#             test_doc_req_or_not = True
#         else:
#             test_doc_req_or_not = False

#         return [SlotSet("valid_FUD_exists", valid_FUD_exists), SlotSet("FUD_probability", FUD_probability), SlotSet("FUD", FUD), SlotSet("test_doc_req_or_not", test_doc_req_or_not)]
    



# class ActionGetEstimatedCostAndETD(Action):
#     def name(self) -> Text:
#         return "action_get_estimated_cost_and_ETD"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         model_from_backend = tracker.get_slot("model_name")
#         problem_description = tracker.get_slot("problem_description")
#         warranty_status = tracker.get_slot("warranty_status")


#         ETD_df = pd.read_csv("ETD.csv")
#         ETD_df['embeddings'] = ETD_df['embeddings'].apply(lambda x: torch.tensor(eval(x)))

#         filtered_df = ETD_df[(ETD_df['model'] == model_from_backend) & (ETD_df['warranty_status'] == warranty_status)].reset_index(drop = True)
        
#         if filtered_df.shape[0]>0:
#         # Corpus with example sentences
#             corpus_embeddings = filtered_df['embeddings'].tolist()
#             query_embedding = embedder.encode(problem_description, convert_to_tensor=True)
            
#             hits = util.semantic_search(query_embedding, corpus_embeddings, top_k=1)
#             hit = hits[0][0]

#             if hit['score']>0.7:
#                 ETD = int(filtered_df['ETD'][hit['corpus_id']])
#             else:
#                 ETD = 'Unknown'
#         else:
#             ETD = 'Unknown'
            
#         estimated_cost = 1000



#         if ETD != 'Unknown':
#             valid_ETD_exists = True
#         else:
#             valid_ETD_exists = False


#         if estimated_cost != 'Unknown':
#             valid_estimated_cost_exists = True
#         else:
#             valid_estimated_cost_exists = False


#         return [SlotSet("ETD", ETD), SlotSet("estimated_cost", estimated_cost), SlotSet("valid_ETD_exists", valid_ETD_exists), SlotSet("valid_estimated_cost_exists", valid_estimated_cost_exists)]




# # class ActionKnowTestDocReqOrNot(Action):
# #     def name(self) -> Text:
# #         return "action_know_test_doc_req_or_not"

# #     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
# #         customer_id="ADTRAN"
# #         model="1200G"

# #         test_doc_req_or_not = True
# #         return [SlotSet("test_doc_req_or_not", test_doc_req_or_not)]


# class ActionAssessingTheTestDoc(Action):
#     def name(self) -> Text:
#         return "action_assessing_the_test_doc"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         retest_required = True
#         retest_suggestion = "The temperature range specified for testing this unit is between 90 and 120 degrees Celsius."

#         if retest_required:
#             return [SlotSet("retest_required", retest_required), SlotSet("retest_suggestion", retest_suggestion)]
#         else:
#             return [SlotSet("retest_required", retest_required)]


# class ActionExtractUserID(Action):
#     def name(self) -> Text:
#         return "action_extract_user_id"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         user_id = 93

#         return [SlotSet("user_id", user_id)]


# class ActionSettingAddress(Action):
#     def name(self) -> Text:
#         return "action_setting_address"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         user_id = tracker.get_slot("user_id")

#         db_name = "newacaciaAppPortal"
#         mydb = mysql.connector.connect(
#             host=os.environ["rds_host"],
#             user=os.environ["name"],
#             password=os.environ["password"],
#             database=db_name
#         )

#         QUERY = "select users_id, ship_to_address from account_rmacustomermapping"
#         customer_account_mapping = pd.read_sql_query(QUERY, con=mydb)

#         # if customer_account_mapping.size != 0:
#         #     dummy_variable = "Connected to DB"
#         # else:
#         #     dummy_variable = "Not Connected to DB"

#         serial_number = str(tracker.get_slot("serial_number"))
#         part_number = str(tracker.get_slot("part_number"))
#         sn_pn_mapping = pd.read_csv("SN_PN_mapping.csv")
#         sn_pn_mapping['serial_number'] = sn_pn_mapping['serial_number'].astype(str)
#         sn_pn_mapping['part_number'] = sn_pn_mapping['part_number'].astype(str)
#         sn_pn_mapping['ship_to_site_num'] = sn_pn_mapping['ship_to_site_num'].astype(str)

#         if int(user_id) in customer_account_mapping['users_id'].tolist():
#             if len(customer_account_mapping[customer_account_mapping['users_id']==user_id]['ship_to_address'].dropna()) > 0:
#                 ship_to_address = customer_account_mapping[customer_account_mapping['users_id']==user_id]['ship_to_address'].iloc[0]
#                 ship_from_address = ship_to_address
#             else:
#                 ship_to_address = sn_pn_mapping[(sn_pn_mapping['serial_number'] == serial_number) & (sn_pn_mapping['part_number'] == part_number)]['ship_to_site_num'].iloc[0]
#                 ship_from_address = ship_to_address

#         else:
#             ship_to_address = sn_pn_mapping[(sn_pn_mapping['serial_number'] == serial_number) & (sn_pn_mapping['part_number'] == part_number)]['ship_to_site_num'].iloc[0]
#             ship_from_address = ship_to_address

#         return [SlotSet("ship_to_address", ship_to_address), SlotSet("ship_from_address", ship_from_address)]




# class ActionSetServiceTypeToReturnAndReplace(Action):
#     def name(self) -> Text:
#         return "action_set_service_type_to_Return_and_Replace"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         service_type = "Return and Replace"

#         return [SlotSet("service_type", service_type)]



# # class ActionSetPartNumberToNull(Action):
# #     def name(self) -> Text:
# #         return "action_set_part_number_to_null"

# #     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

# #         part_number = None

# #         return [SlotSet("part_number", part_number)]



# class ActionSetRMAForCreationValue(Action):
#     def name(self) -> Text:
#         return "action_set_RMA_for_creation_value"

#     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         ship_to_address_correct_or_not = tracker.get_slot("ship_to_address_correct_or_not")
#         ship_from_address_correct_or_not = tracker.get_slot("ship_from_address_correct_or_not")

#         if ship_to_address_correct_or_not and ship_from_address_correct_or_not:
#             RMA_for_creation = True
#         else:
#             RMA_for_creation = False

#         return [SlotSet("RMA_for_creation", RMA_for_creation)]
    




# # class ActionCustomJson(Action):
# #     def name(self) -> Text:
# #         return "action_custom_json"

# #     async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

# #         message = {"payload": "location"}
# #         # dispatcher.utter_message("Test",json_message=message)
# #         dispatcher.utter_custom_json(message)
# #         return []



# # class ActionSessionStart(Action):
# #     def name(self) -> Text:
# #         return "action_session_start"


# #     async def run(
# #       self, dispatcher, tracker: Tracker, domain: Dict[Text, Any]
# #     ) -> List[Dict[Text, Any]]:

# #         # the session should begin with a `session_started` event
# #         events = [SessionStarted()]

# #         dispatcher.utter_message("Hello there. How can I help you today?")

# #         # an `action_listen` should be added at the end as a user message follows
# #         events.append(ActionExecuted("action_listen"))

# #         return events
    


# # class ActionSessionStart(Action):
# #     def name(self) -> Text:
# #         return "action_session_start"

# #     async def run(
# #       self, dispatcher, tracker: Tracker, domain: Dict[Text, Any]
# #     ) -> List[Dict[Text, Any]]:
# #         metadata = tracker.get_slot("session_started_metadata")

# #         # Do something with the metadata
# #         print(metadata)

# #         # the session should begin with a `session_started` event and an `action_listen`
# #         # as a user message follows
# #         return [SessionStarted(), ActionExecuted("action_listen")]


# # dispatcher.utter_custom_json()





























#############################################################################################################################################################################################################
#############################################################################################################################################################################################################
#############################################################################################################################################################################################################
#############################################################################################################################################################################################################

























class ActionCheckSerialNumber(Action):
    def name(self) -> Text:
        return "action_check_serial_number"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        sn_pn_mapping = pd.read_csv("SN_PN_mapping.csv")
        sn_pn_mapping['serial_number'] = sn_pn_mapping['serial_number'].astype(str)
        sn_pn_mapping['part_number'] = sn_pn_mapping['part_number'].astype(str)
        sn_list = sn_pn_mapping['serial_number'].to_list()
        serial_number = str(tracker.get_slot("serial_number"))

        sn_is_valid = serial_number in sn_list
        part_number = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['part_number'].iloc[0]
        model_name = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['model'].iloc[0]

        if any(char.isalpha() for char in part_number.split('-')[-1]):
            check_if_engineering_sample = True
        else:
            check_if_engineering_sample = False

        # initial_address_validation = False



        if serial_number in trial_dict.keys():
            shipped_date = trial_dict[serial_number]['shipped_date']
            warranty_up_date = trial_dict[serial_number]['warranty_up_date']
            tod = pd.Timestamp.today()
            Warranty_Up_Date = pd.Timestamp(warranty_up_date)
            Shipped_Date = pd.Timestamp(shipped_date)

            if tod > Warranty_Up_Date:
                warrantable = False
            else:
                warrantable = True

            if warrantable:
                warranty_status = "InWarranty"
            else:
                warranty_status = "OutWarranty"


        else:
            shipped_date = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['shipped_date'].iloc[0]
            warranty_up_date = sn_pn_mapping[sn_pn_mapping['serial_number'] == serial_number]['warranty_up_date'].iloc[0]

            tod = pd.Timestamp.today()
            Warranty_Up_Date = pd.Timestamp(warranty_up_date)
            Shipped_Date = pd.Timestamp(shipped_date)


            if tod > Warranty_Up_Date:
                warrantable = False
            else:
                warrantable = True

            if warrantable:
                warranty_status = "InWarranty"
            else:
                warranty_status = "OutWarranty"



        difference_in_days = (tod - Shipped_Date).days

        if difference_in_days > 60:
            DOA_should_be_part_of_POF = False
        else:
            DOA_should_be_part_of_POF = True


        db_name = "newacaciaAppPortal"
        mydb = mysql.connector.connect(
            host=os.environ["rds_host"],
            user=os.environ["name"],
            password=os.environ["password"],
            database=db_name
        )

        QUERY = "select part, is_active FROM newacaciaAppPortal.account_customerpartmodel where part = %s;"
        part_number_status = pd.read_sql_query(QUERY, con=mydb, params=[part_number])


        if part_number_status['is_active'][0] == 1:
            serviceable = True
        else:
            serviceable = False
            

        if sn_is_valid:
            return [SlotSet("DOA_should_be_part_of_POF", DOA_should_be_part_of_POF), SlotSet("serviceable", serviceable), SlotSet("shipped_date", shipped_date), SlotSet("model_name", model_name), SlotSet("warranty_status", warranty_status), SlotSet("warrantable", warrantable), SlotSet("sn_is_valid", sn_is_valid), SlotSet("part_number", part_number), SlotSet("check_if_engineering_sample", check_if_engineering_sample)]
        else:
            return [SlotSet("sn_is_valid", sn_is_valid)]



class ActionGetFUDDetails(Action):
    def name(self) -> Text:
        return "action_get_FUD_details"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        serial_number = tracker.get_slot("serial_number")
        model_from_backend = tracker.get_slot("model_name")
        problem_description = tracker.get_slot("problem_description")

        FUD_df = pd.read_csv("FUD.csv")
        FUD_df['embeddings'] = FUD_df['embeddings'].apply(lambda x: torch.tensor(eval(x)))
        filtered_df = FUD_df[FUD_df['model'] == model_from_backend].reset_index(drop = True)


        if serial_number in trial_dict.keys():
            FUD = trial_dict[serial_number]['FUD']
            FUD_probability = trial_dict[serial_number]['FUD_probability']

            if FUD != 'Unknown':
                valid_FUD_exists = True
            else:
                valid_FUD_exists = False


            if FUD=="NFF":
                test_doc_req_or_not = True
            else:
                test_doc_req_or_not = False

            # if FUD=="Non-Repairable":
            #     FUD_probability = trial_dict[serial_number]['FUD_probability']
            # else:
            #     FUD_probability = "" 

        else:

            if filtered_df.shape[0]>0:
            # Corpus with example sentences
                corpus_embeddings = filtered_df['embeddings'].tolist()
                query_embedding = embedder.encode(problem_description, convert_to_tensor=True)
                
                hits = util.semantic_search(query_embedding, corpus_embeddings, top_k=1)
                hit = hits[0][0]

                if hit['score']>0.7:
                    prob_Non_Repairable = int(filtered_df['prob_Non-Repairable'][hit['corpus_id']])
                    prob_Repaired = int(filtered_df['prob_Repaired'][hit['corpus_id']])
                    prob_NFF = int(filtered_df['prob_NFF'][hit['corpus_id']])
                    probabilities = {'Non_Repairable': prob_Non_Repairable, 'Repaired': prob_Repaired, 'NFF': prob_NFF}
                else:
                    prob_Non_Repairable = prob_Repaired = prob_NFF = 'Unknown'
            else:
                prob_Non_Repairable = prob_Repaired = prob_NFF = 'Unknown'


            FUD = 'Unknown'
            FUD_probability = 'Unknown'   

            if isinstance(prob_Non_Repairable, int):
                # Check if any of the probabilities exceed the threshold
                for key, value in probabilities.items():
                    if value > 60:
                        FUD = key
                        FUD_probability = value
                        break  # Stop after finding the first probability that exceeds the threshold

            if FUD != 'Unknown':
                valid_FUD_exists = True
            else:
                valid_FUD_exists = False


            if FUD=="NFF":
                test_doc_req_or_not = True
            else:
                test_doc_req_or_not = False

            # if FUD=="Non-Repairable":
            #     FUD_probability = 70 
            # else:
            #     FUD_probability = "" 

        return [SlotSet("valid_FUD_exists", valid_FUD_exists), SlotSet("FUD_probability", FUD_probability), SlotSet("FUD", FUD), SlotSet("test_doc_req_or_not", test_doc_req_or_not)]
    


class ActionGetEstimatedCostAndETD(Action):
    def name(self) -> Text:
        return "action_get_estimated_cost_and_ETD"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        serial_number = tracker.get_slot("serial_number")
        model_from_backend = tracker.get_slot("model_name")
        problem_description = tracker.get_slot("problem_description")
        warranty_status = tracker.get_slot("warranty_status")

        if serial_number in trial_dict.keys():
            ETD = trial_dict[serial_number]['ETD']
            estimated_cost = trial_dict[serial_number]['estimated_cost']

        else:
            ETD_df = pd.read_csv("ETD.csv")
            ETD_df['embeddings'] = ETD_df['embeddings'].apply(lambda x: torch.tensor(eval(x)))

            filtered_df = ETD_df[(ETD_df['model'] == model_from_backend) & (ETD_df['warranty_status'] == warranty_status)].reset_index(drop = True)
            
            if filtered_df.shape[0]>0:
            # Corpus with example sentences
                corpus_embeddings = filtered_df['embeddings'].tolist()
                query_embedding = embedder.encode(problem_description, convert_to_tensor=True)
                
                
                hits = util.semantic_search(query_embedding, corpus_embeddings, top_k=1)
                hit = hits[0][0]

                if hit['score']>0.7:
                    ETD = int(filtered_df['ETD'][hit['corpus_id']])
                else:
                    ETD = 'Unknown'
            else:
                ETD = 'Unknown'
                
            estimated_cost = 1000



        if ETD != 'Unknown':
            valid_ETD_exists = True
        else:
            valid_ETD_exists = False


        if estimated_cost != 'Unknown':
            valid_estimated_cost_exists = True
        else:
            valid_estimated_cost_exists = False


        return [SlotSet("ETD", ETD), SlotSet("estimated_cost", estimated_cost), SlotSet("valid_ETD_exists", valid_ETD_exists), SlotSet("valid_estimated_cost_exists", valid_estimated_cost_exists)]


class ActionAssessingTheTestDoc(Action):
    def name(self) -> Text:
        return "action_assessing_the_test_doc"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        retest_required = True
        retest_suggestion = "The temperature range specified for testing this unit is between 90 and 120 degrees Celsius."

        if retest_required:
            return [SlotSet("retest_required", retest_required), SlotSet("retest_suggestion", retest_suggestion)]
        else:
            return [SlotSet("retest_required", retest_required)]


class ActionExtractUserID(Action):
    def name(self) -> Text:
        return "action_extract_user_id"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        user_id = 93

        return [SlotSet("user_id", user_id)]



class ActionSettingAddress(Action):
    def name(self) -> Text:
        return "action_setting_address"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        user_id = tracker.get_slot("user_id")

        db_name = "newacaciaAppPortal"
        mydb = mysql.connector.connect(
            host=os.environ["rds_host"],
            user=os.environ["name"],
            password=os.environ["password"],
            database=db_name
        )

        QUERY = "select users_id, ship_to_address from account_rmacustomermapping"
        customer_account_mapping = pd.read_sql_query(QUERY, con=mydb)

        # if customer_account_mapping.size != 0:
        #     dummy_variable = "Connected to DB"
        # else:
        #     dummy_variable = "Not Connected to DB"

        serial_number = str(tracker.get_slot("serial_number"))
        part_number = str(tracker.get_slot("part_number"))
        sn_pn_mapping = pd.read_csv("SN_PN_mapping.csv")
        sn_pn_mapping['serial_number'] = sn_pn_mapping['serial_number'].astype(str)
        sn_pn_mapping['part_number'] = sn_pn_mapping['part_number'].astype(str)
        sn_pn_mapping['ship_to_site_num'] = sn_pn_mapping['ship_to_site_num'].astype(str)

        if int(user_id) in customer_account_mapping['users_id'].tolist():
            if len(customer_account_mapping[customer_account_mapping['users_id']==user_id]['ship_to_address'].dropna()) > 0:
                ship_to_address = customer_account_mapping[customer_account_mapping['users_id']==user_id]['ship_to_address'].iloc[0]
                ship_from_address = ship_to_address
            else:
                ship_to_address = sn_pn_mapping[(sn_pn_mapping['serial_number'] == serial_number) & (sn_pn_mapping['part_number'] == part_number)]['ship_to_site_num'].iloc[0]
                ship_from_address = ship_to_address

        else:
            ship_to_address = sn_pn_mapping[(sn_pn_mapping['serial_number'] == serial_number) & (sn_pn_mapping['part_number'] == part_number)]['ship_to_site_num'].iloc[0]
            ship_from_address = ship_to_address

        return [SlotSet("ship_to_address", ship_to_address), SlotSet("ship_from_address", ship_from_address)]


class ActionSetServiceTypeToReturnAndReplace(Action):
    def name(self) -> Text:
        return "action_set_service_type_to_Return_and_Replace"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        service_type = "Return and Replace"

        return [SlotSet("service_type", service_type)]




class ActionSetRMAForCreationValue(Action):
    def name(self) -> Text:
        return "action_set_RMA_for_creation_value"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        ship_to_address_correct_or_not = tracker.get_slot("ship_to_address_correct_or_not")
        ship_from_address_correct_or_not = tracker.get_slot("ship_from_address_correct_or_not")

        if ship_to_address_correct_or_not and ship_from_address_correct_or_not:
            RMA_for_creation = True
        else:
            RMA_for_creation = False

        return [SlotSet("RMA_for_creation", RMA_for_creation)]





################################################################################################################################################################################################################




class ActionCheckRMANumber(Action):
    def name(self) -> Text:
        return "action_check_rma_number"

    async def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        corpus_file = pd.read_csv("RMA_Combined_Report.csv")
        corpus_file['rma_number'] = corpus_file['rma_number'].astype(str)

        # db_name = "newacaciaAppPortal"
        # mydb = mysql.connector.connect(
        #     host=os.environ["rds_host"],
        #     user=os.environ["name"],
        #     password=os.environ["password"],
        #     database=db_name
        # )

        # QUERY = "select part, is_active FROM newacaciaAppPortal.account_customerpartmodel where part = %s;"
        # corpus_file = pd.read_sql_query(QUERY, con=mydb, params=[part_number])


        valid_rma_list = set(corpus_file['rma_number'].astype('str').to_list())

        status_check_rma_number = tracker.get_slot("status_check_rma_number")

        if status_check_rma_number in valid_rma_list:
            status_check_rma_is_valid = True
        else:
            status_check_rma_is_valid = False


        if status_check_rma_is_valid:
            required_details = ["rma_number", "serial_number", "model", "part_number", "warranty_up", "warranty_status", "manufacture_date", "shipped_date", "rma_creation_date", "rma_receipt_date", "return_reason", "point_of_failure", "service_type", "current_status", "current_status_date", "Failure Mode", "affected_system", "defect_source", "component_pn", "final_unit_determination", "problem_description", "Warrantable", "repair_cost", "priceToInvoice", "customer_repair_decision"]

            corpus_data = {}

            for i in required_details:
                variable_name = i.replace(' ', '_').lower()
                rma_details = corpus_file[corpus_file['rma_number']==status_check_rma_number]
                variable_value = rma_details[i].iloc[0]
                corpus_data[variable_name] = variable_value


        if status_check_rma_is_valid:
            return [SlotSet("status_check_rma_is_valid", status_check_rma_is_valid), SlotSet("status_check_rma_number", str(corpus_data['rma_number'])), SlotSet("status_check_serial_number", str(corpus_data['serial_number'])), SlotSet("status_check_model", corpus_data['model']), SlotSet("status_check_warranty_up", str(corpus_data['warranty_up'])), SlotSet("status_check_warranty_status", corpus_data['warranty_status']), SlotSet("status_check_manufacture_date", str(corpus_data['manufacture_date'])), SlotSet("status_check_shipped_date", str(corpus_data['shipped_date'])), SlotSet("status_check_rma_creation_date", str(corpus_data['rma_creation_date'])), SlotSet("status_check_rma_receipt_date", str(corpus_data['rma_receipt_date'])), SlotSet("status_check_return_reason", corpus_data['return_reason']), SlotSet("status_check_point_of_failure", corpus_data['point_of_failure']), SlotSet("status_check_service_type", corpus_data['service_type']), SlotSet("status_check_current_status_date", str(corpus_data['current_status_date'])), SlotSet("status_check_current_status", corpus_data['current_status']), SlotSet("status_check_final_unit_determination", corpus_data['final_unit_determination']), SlotSet("status_check_defect_source", corpus_data['defect_source']),  SlotSet("status_check_problem_description", corpus_data['problem_description'])]
        else:
            return [SlotSet("status_check_rma_is_valid", status_check_rma_is_valid)]

################################################################################################################################################################################################################







