<!-- Important commands -->

rasa train
rasa inspect
rasa run actions
rasa run -m--enable-api --cors "*" --debug